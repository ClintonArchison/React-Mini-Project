import React ,{useState} from 'react';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';

const Home = () => (
  <div>
    <h2>Home</h2>
    <p>This is the home page.</p>
  </div>
);

const About = () => (
  <div>
    <h2>About</h2>
    <p>This is the about page.</p>
  </div>
);

const Contact = () => (
  <div>
    <h2>Contact</h2>
    <p>This is the contact page.</p>
  </div>
);

const NavBarForStudentPortal: React.FC = () => {
  return (
    <div>
      <nav className="navbar bg-primary" data-bs-theme="dark">
        <h3 className='text-white ms-3'>Welcome to Students Portal</h3>
        <form className="d-flex ms-auto" role="search">
          <button className="btn btn-warning me-2" type="submit" >Log Out</button>
        </form>
        <div className="rounded-circle bg-light text-dark p-3 me-2" >CA</div>
        <p className="mb-0 ms-1 p-3 text-white" ><b> Clinton Archison</b></p>
      </nav>
      <Router>
      <div>
        <nav>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/about">About</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
          </ul>
        </nav>

        <hr />

        <Route path="/" Component={Home} />
        <Route path="/about" Component={About} />
        <Route path="/contact" Component={Contact} />
      </div>
    </Router>
    </div>
  );
};

export default NavBarForStudentPortal;
