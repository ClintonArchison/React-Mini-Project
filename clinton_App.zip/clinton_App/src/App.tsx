import Message from './components/DashBoard'
function App(){
  return <div><Message></Message></div>
}
export default App;